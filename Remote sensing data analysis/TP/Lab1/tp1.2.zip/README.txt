Read the document in TP1.pdf
Follow the assignement filling-in the solutions as described in TP-collection.ipynb
